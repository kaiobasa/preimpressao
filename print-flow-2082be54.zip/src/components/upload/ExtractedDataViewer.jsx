import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Eye } from 'lucide-react';

const formatDate = (dateString) => {
  if (!dateString) return 'N/A';
  try {
    return format(new Date(dateString), 'dd/MM/yyyy', { locale: ptBR });
  } catch {
    return 'Data inválida';
  }
};

const DataGroup = ({ title, children }) => (
  <div className="mb-6">
    <h3 className="text-sm font-medium text-gray-500 mb-3">{title}</h3>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
      {children}
    </div>
  </div>
);

const DataItem = ({ label, value, fullWidth = false }) => (
  <div className={fullWidth ? "col-span-full" : ""}>
    <p className="text-xs text-gray-500 mb-1">{label}</p>
    <p className="font-medium text-gray-900">{value || 'N/A'}</p>
  </div>
);

const ExtractedDataViewer = ({ op }) => {
  if (!op) return null;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl font-semibold">Dados Extraídos</CardTitle>
          {op.op_pdf_url && (
            <Button variant="outline" size="sm" asChild>
              <a href={op.op_pdf_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Ver PDF
              </a>
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <DataGroup title="Informações Gerais">
          <DataItem label="Número da OP" value={op.numero_op} />
          <DataItem label="Orçamento" value={op.orcamento} />
          <DataItem label="Emissão" value={formatDate(op.emissao)} />
          <DataItem label="Data da Prova" value={formatDate(op.data_prova)} />
          <DataItem label="Prazo de Entrega" value={formatDate(op.prazo_entrega)} />
          <DataItem label="Quantidade" value={op.quantidade} />
          <DataItem label="Vendedor" value={op.vendedor} />
        </DataGroup>

        <DataGroup title="Informações do Cliente">
          <DataItem label="Cliente" value={op.cliente} />
          <DataItem label="Contato" value={op.contato} />
          <DataItem label="Endereço" value={op.endereco} fullWidth />
        </DataGroup>

        <DataGroup title="Informações do Produto">
          <DataItem label="Título" value={op.titulo} />
          <DataItem label="ISBN" value={op.isbn} />
          <DataItem label="Formato" value={op.formato} />
          <DataItem label="Tipo de Prova" value={op.tipo_prova} />
          <DataItem label="Entrega" value={op.entrega} />
        </DataGroup>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Capa</h3>
            <div className="space-y-3">
              <div>
                <p className="text-xs text-gray-500 mb-1">Papel</p>
                <p className="font-medium text-gray-900">{op.capa_papel || 'N/A'}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Cores</p>
                <p className="font-medium text-gray-900">{op.capa_cores || 'N/A'}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Laminação</p>
                <p className="font-medium text-gray-900">{op.capa_laminacao || 'N/A'}</p>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-sm font-medium text-gray-700 mb-3">Miolo</h3>
            <div className="space-y-3">
              <div>
                <p className="text-xs text-gray-500 mb-1">Número de Páginas</p>
                <p className="font-medium text-gray-900">{op.miolo_paginas || 'N/A'}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Papel</p>
                <p className="font-medium text-gray-900">{op.miolo_papel || 'N/A'}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Cores</p>
                <p className="font-medium text-gray-900">{op.miolo_cores || 'N/A'}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Acabamento</h3>
            <p className="font-medium text-gray-900 bg-gray-50 p-3 rounded">{op.acabamento || 'N/A'}</p>
          </div>
          
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Shrink</h3>
            <Badge variant={op.shrink ? "success" : "outline"}>
              {op.shrink ? "Sim" : "Não"}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExtractedDataViewer;