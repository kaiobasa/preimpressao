
import React, { useState, useRef } from 'react';
import { Upload, File, AlertCircle, X, CheckCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { UploadFile, ExtractDataFromUploadedFile } from '@/api/integrations';
import { OrdemProducao } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const simplifiedExtractionSchema = {
    type: "object",
    properties: {
        numero_op: { type: "string", description: "Número da OP" },
        orcamento: { type: "string", description: "Número do Orçamento" },
        emissao: { type: "string", format: "date", description: "Data de Emissão (AAAA-MM-DD)" },
        data_prova: { type: "string", format: "date", description: "Data da Prova (AAAA-MM-DD)" },
        prazo_entrega: { type: "string", format: "date", description: "Prazo de Entrega (AAAA-MM-DD)" },
        quantidade: { type: "number", description: "Quantidade" },
        cliente: { type: "string", description: "Nome do Cliente" },
        contato: { type: "string", description: "Contato do Cliente" },
        endereco: { type: "string", description: "Endereço de Entrega" },
        titulo: { type: "string", description: "Título da Obra" },
        isbn: { type: "string", description: "ISBN" },
        formato: { type: "string", description: "Formato do Material (ex: 21x28 cm)" },
        capa_papel: { type: "string", description: "Papel da Capa" },
        capa_cores: { type: "string", description: "Cores da Capa (ex: 4x0)" },
        capa_laminacao: { type: "string", description: "Laminação da Capa" },
        miolo_paginas: { type: "number", description: "Número de Páginas do Miolo" },
        miolo_papel: { type: "string", description: "Papel do Miolo" },
        miolo_cores: { type: "string", description: "Cores do Miolo (ex: 1x1)" },
        acabamento: { type: "string", description: "Tipo de Acabamento" },
        shrink: { type: "boolean", description: "Aplicar Shrink (true/false)" },
        tipo_prova: { type: "string", description: "Tipo de Prova" },
        entrega: { type: "string", description: "Local/Observações de Entrega" },
    }
};

const UploadForm = ({ existingOP = null, onComplete }) => {
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [extracting, setExtracting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef(null);
  const navigate = useNavigate();

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
    } else {
      setFile(null);
      setError('Por favor, selecione um arquivo PDF válido.');
    }
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const handleDrop = (event) => {
    event.preventDefault();
    
    const droppedFile = event.dataTransfer.files[0];
    if (droppedFile && droppedFile.type === 'application/pdf') {
      setFile(droppedFile);
      setError(null);
    } else {
      setError('Por favor, selecione um arquivo PDF válido.');
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setError('Por favor, selecione um arquivo PDF válido.');
      return;
    }

    setError(null);
    setUploading(true);
    setProgress(0);
    
    try {
      // Simular progresso de upload
      const interval = setInterval(() => {
        setProgress(prev => Math.min(prev + 5, 95));
      }, 100);
      
      // Fazer o upload real
      const { file_url } = await UploadFile({ file });
      
      clearInterval(interval);
      setProgress(100);
      setUploading(false);
      setFileUrl(file_url);
      
      // Após upload bem sucedido, extrair dados
      await extractData(file_url);
    } catch (error) {
      setUploading(false);
      setProgress(0);
      setError('Erro ao fazer upload do arquivo. Por favor, tente novamente.');
    }
  };

  const extractData = async (url) => {
    setExtracting(true);
    
    try {
      const result = await ExtractDataFromUploadedFile({
        file_url: url,
        json_schema: simplifiedExtractionSchema // Usar o schema simplificado
      });
      
      if (result.status === 'success' && result.output) {
        const opData = {
          ...result.output,
          op_pdf_url: url,
          status: 'esperando_arquivos', // Status após extração bem-sucedida
          // Adicionar data_upload e empresa se for uma nova OP vinda daqui
          data_upload: existingOP ? existingOP.data_upload : new Date().toISOString(),
          // Empresa pode ser um campo a ser preenchido manualmente aqui, ou ter um padrão
        };
        
        if (existingOP) {
          await OrdemProducao.update(existingOP.id, opData);
        } else {
          // Se for uma nova OP criada diretamente pela pré-impressão, pode faltar 'empresa' e 'vendedor'
          // Poderia adicionar campos para isso no formulário, ou deixar para preencher depois
          await OrdemProducao.create(opData);
        }
        
        setSuccess(true);
        
        setTimeout(() => {
          if (onComplete) {
            onComplete();
          } else {
            navigate(createPageUrl('Dashboard'));
          }
        }, 2000);
      } else {
         await OrdemProducao.create({ // Cria a OP mesmo com falha na extração
            op_pdf_url: url,
            status: 'extraindo',
            log_extracao: `Falha na extração: ${result.details || 'Erro desconhecido.'}`,
            data_upload: existingOP ? existingOP.data_upload : new Date().toISOString(),
        });
        setError(`Erro ao extrair dados do PDF: ${result.details || 'Verifique se é uma OP válida.'}`);
      }
    } catch (error) {
      setError('Erro crítico ao extrair dados do PDF. Por favor, verifique o arquivo.');
      // Considerar criar a OP com status de erro aqui também se necessário
    } finally {
      setExtracting(false);
    }
  };

  return (
    <div className="bg-white rounded-lg border shadow-sm p-6">
      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      {success ? (
        <div className="flex flex-col items-center justify-center py-8">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Processamento Concluído</h3>
          <p className="text-gray-500 text-center mb-6">
            A ordem de produção foi processada com sucesso!
          </p>
          <Button 
            onClick={() => navigate(createPageUrl('Dashboard'))}
            className="bg-blue-600 hover:bg-blue-700"
          >
            Voltar ao Painel
          </Button>
        </div>
      ) : (
        <>
          <h2 className="text-xl font-semibold mb-6">Upload da Ordem de Produção (PDF)</h2>
          
          <div 
            className={`border-2 border-dashed rounded-lg p-8 text-center mb-6 ${
              file ? 'border-blue-300 bg-blue-50' : 'border-gray-300 hover:border-blue-300'
            }`}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              accept="application/pdf"
            />
            
            {file ? (
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <File className="w-8 h-8 text-blue-600" />
                </div>
                <p className="text-gray-800 font-medium mb-2">{file.name}</p>
                <p className="text-gray-500 mb-4">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setFile(null)}
                  >
                    <X className="w-4 h-4 mr-2" />
                    Remover
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <Upload className="w-8 h-8 text-gray-400" />
                </div>
                <p className="font-medium text-gray-700 mb-2">
                  Arraste e solte o arquivo PDF aqui
                </p>
                <p className="text-gray-500 text-sm mb-6">
                  ou
                </p>
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                >
                  Selecionar Arquivo
                </Button>
              </div>
            )}
          </div>
          
          {(uploading || extracting) && (
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <Label>{uploading ? 'Fazendo upload...' : 'Extraindo dados...'}</Label>
                <span className="text-sm text-gray-500">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
          
          <div className="flex justify-end">
            <Button
              disabled={!file || uploading || extracting}
              onClick={handleUpload}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {uploading || extracting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {uploading ? 'Enviando...' : 'Processando...'}
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Processar Ordem
                </>
              )}
            </Button>
          </div>
        </>
      )}
    </div>
  );
};

export default UploadForm;
