import React, { useState, useRef } from 'react';
import { Upload, File, Image, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { UploadFile } from '@/api/integrations';
import { ArquivoProducao } from '@/api/entities';

const FileUploader = ({ ordemProducaoId, onUploadComplete }) => {
  const [activeTab, setActiveTab] = useState('capa');
  const [files, setFiles] = useState([]);
  const [fileType, setFileType] = useState('capa');
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);

  const handleFileChange = (event) => {
    const selectedFiles = Array.from(event.target.files);
    if (selectedFiles.length > 0) {
      setFiles(selectedFiles);
      setError(null);
    }
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  const handleDrop = (event) => {
    event.preventDefault();
    
    const droppedFiles = Array.from(event.dataTransfer.files);
    if (droppedFiles.length > 0) {
      setFiles(droppedFiles);
      setError(null);
    }
  };

  const handleUpload = async () => {
    if (files.length === 0) {
      setError('Por favor, selecione pelo menos um arquivo.');
      return;
    }

    setError(null);
    setUploading(true);
    setProgress(0);
    
    try {
      // Simular progresso de upload
      const interval = setInterval(() => {
        setProgress(prev => Math.min(prev + 5, 95));
      }, 100);
      
      for (const file of files) {
        // Fazer o upload real
        const { file_url } = await UploadFile({ file });
        
        // Salvar informações do arquivo
        await ArquivoProducao.create({
          ordem_producao_id: ordemProducaoId,
          nome_arquivo: file.name,
          tipo_arquivo: fileType,
          arquivo_original_url: file_url,
          status_processamento: 'aguardando'
        });
      }
      
      clearInterval(interval);
      setProgress(100);
      
      // Limpar após upload bem sucedido
      setTimeout(() => {
        setUploading(false);
        setFiles([]);
        setProgress(0);
        if (onUploadComplete) {
          onUploadComplete();
        }
      }, 1000);
    } catch (error) {
      setUploading(false);
      setProgress(0);
      setError('Erro ao fazer upload dos arquivos. Por favor, tente novamente.');
    }
  };

  const removeFile = (index) => {
    setFiles(prevFiles => prevFiles.filter((_, i) => i !== index));
  };

  const handleTabChange = (value) => {
    setActiveTab(value);
    setFileType(value);
  };

  return (
    <div className="bg-white rounded-lg border shadow-sm">
      <Tabs defaultValue="capa" value={activeTab} onValueChange={handleTabChange}>
        <div className="px-6 pt-6">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="capa">Capa</TabsTrigger>
            <TabsTrigger value="miolo">Miolo</TabsTrigger>
            <TabsTrigger value="outros">Outros</TabsTrigger>
          </TabsList>
        </div>

        <div className="p-6">
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <TabsContent value="capa" className="mt-0">
            <h3 className="text-lg font-medium mb-2">Upload da Capa</h3>
            <p className="text-gray-500 text-sm mb-4">
              Envie os arquivos da capa do livro (PDF, AI, INDD, etc).
            </p>
          </TabsContent>
          
          <TabsContent value="miolo" className="mt-0">
            <h3 className="text-lg font-medium mb-2">Upload do Miolo</h3>
            <p className="text-gray-500 text-sm mb-4">
              Envie os arquivos do miolo do livro (PDF ou INDD).
            </p>
          </TabsContent>
          
          <TabsContent value="outros" className="mt-0">
            <h3 className="text-lg font-medium mb-2">Outros Arquivos</h3>
            <p className="text-gray-500 text-sm mb-4">
              Envie arquivos adicionais como fontes, imagens ou instruções.
            </p>
          </TabsContent>
          
          <div 
            className={`border-2 border-dashed rounded-lg p-8 text-center mb-6 ${
              files.length > 0 ? 'border-blue-300 bg-blue-50' : 'border-gray-300 hover:border-blue-300'
            }`}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              multiple
            />
            
            {files.length > 0 ? (
              <div>
                <div className="max-h-60 overflow-auto mb-4">
                  {files.map((file, index) => (
                    <div key={index} className="flex items-center justify-between bg-white p-3 rounded mb-2 shadow-sm">
                      <div className="flex items-center">
                        {file.type.startsWith('image/') ? (
                          <Image className="w-5 h-5 mr-3 text-blue-500" />
                        ) : (
                          <File className="w-5 h-5 mr-3 text-blue-500" />
                        )}
                        <div className="text-left">
                          <p className="text-sm font-medium text-gray-700 truncate" style={{ maxWidth: '250px' }}>
                            {file.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {(file.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(index)}
                        disabled={uploading}
                      >
                        <X className="w-4 h-4 text-gray-500" />
                      </Button>
                    </div>
                  ))}
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                >
                  Adicionar Mais Arquivos
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <Upload className="w-8 h-8 text-gray-400" />
                </div>
                <p className="font-medium text-gray-700 mb-2">
                  Arraste e solte os arquivos aqui
                </p>
                <p className="text-gray-500 text-sm mb-6">
                  ou
                </p>
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                >
                  Selecionar Arquivos
                </Button>
              </div>
            )}
          </div>
          
          {uploading && (
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <Label>Fazendo upload...</Label>
                <span className="text-sm text-gray-500">{progress}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
          
          <div className="flex justify-end">
            <Button
              disabled={files.length === 0 || uploading}
              onClick={handleUpload}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {uploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Enviando...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Fazer Upload
                </>
              )}
            </Button>
          </div>
        </div>
      </Tabs>
    </div>
  );
};

export default FileUploader;