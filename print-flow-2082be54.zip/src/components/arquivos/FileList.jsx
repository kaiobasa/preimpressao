import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { File, Image, Download, Loader2, CheckCircle, AlertCircle, Eye } from 'lucide-react';

const statusConfig = {
  aguardando: {
    icon: Loader2,
    color: 'bg-amber-100 text-amber-700 border-amber-200',
    label: 'Aguardando'
  },
  processando: {
    icon: Loader2,
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    label: 'Processando',
    animate: true
  },
  concluido: {
    icon: CheckCircle,
    color: 'bg-green-100 text-green-700 border-green-200',
    label: 'Concluído'
  },
  erro: {
    icon: AlertCircle,
    color: 'bg-red-100 text-red-700 border-red-200',
    label: 'Erro'
  }
};

const tipoConfig = {
  capa: {
    label: 'Capa',
    color: 'bg-purple-100 text-purple-700 border-purple-200'
  },
  miolo: {
    label: 'Miolo',
    color: 'bg-blue-100 text-blue-700 border-blue-200'
  },
  outros: {
    label: 'Outros',
    color: 'bg-gray-100 text-gray-700 border-gray-200'
  }
};

const FileList = ({ files, onProcessFiles }) => {
  if (!files || files.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Arquivos Enviados</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            Nenhum arquivo enviado ainda.
          </div>
        </CardContent>
      </Card>
    );
  }

  const groupedFiles = files.reduce((acc, file) => {
    const type = file.tipo_arquivo || 'outros';
    if (!acc[type]) {
      acc[type] = [];
    }
    acc[type].push(file);
    return acc;
  }, {});

  // Verificar se há arquivos esperando processamento
  const hasWaitingFiles = files.some(file => file.status_processamento === 'aguardando');

  return (
    <div className="space-y-6">
      {hasWaitingFiles && (
        <div className="flex justify-end mb-2">
          <Button 
            onClick={onProcessFiles}
            className="bg-green-600 hover:bg-green-700"
          >
            Processar Arquivos
          </Button>
        </div>
      )}
      
      {Object.entries(groupedFiles).map(([type, typeFiles]) => (
        <Card key={type}>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center">
              <Badge className={`mr-2 ${tipoConfig[type]?.color || 'bg-gray-100'}`}>
                {tipoConfig[type]?.label || type}
              </Badge>
              Arquivos ({typeFiles.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="divide-y">
              {typeFiles.map(file => {
                const status = statusConfig[file.status_processamento] || statusConfig.aguardando;
                const StatusIcon = status.icon;
                const fileExtension = file.nome_arquivo?.split('.').pop()?.toLowerCase();
                
                return (
                  <div key={file.id} className="py-4 first:pt-0 last:pb-0">
                    <div className="flex justify-between items-start">
                      <div className="flex items-start gap-3">
                        {['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension) ? (
                          <Image className="w-6 h-6 text-blue-500 mt-1" />
                        ) : (
                          <File className="w-6 h-6 text-blue-500 mt-1" />
                        )}
                        <div>
                          <p className="font-medium text-gray-900 mb-1">
                            {file.nome_arquivo}
                          </p>
                          <div className="flex flex-wrap gap-2 text-sm">
                            <Badge className={status.color} variant="secondary">
                              <StatusIcon className={`w-3 h-3 mr-1 ${status.animate ? 'animate-spin' : ''}`} />
                              {status.label}
                            </Badge>
                            <span className="text-gray-500">
                              Enviado em {format(new Date(file.created_date), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                            </span>
                          </div>
                          {file.mensagem_erro && (
                            <p className="text-red-500 text-sm mt-2">{file.mensagem_erro}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {file.preview_url && (
                          <Button variant="outline" size="sm" asChild>
                            <a href={file.preview_url} target="_blank" rel="noopener noreferrer">
                              <Eye className="w-4 h-4 mr-1" />
                              Preview
                            </a>
                          </Button>
                        )}
                        <Button variant="outline" size="sm" asChild>
                          <a href={file.arquivo_processado_url || file.arquivo_original_url} 
                             download 
                             target="_blank" 
                             rel="noopener noreferrer">
                            <Download className="w-4 h-4 mr-1" />
                            {file.arquivo_processado_url ? 'PDF/X-1A' : 'Original'}
                          </a>
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default FileList;