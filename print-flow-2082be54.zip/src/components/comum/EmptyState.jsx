import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const EmptyState = ({ 
  icon: Icon, 
  title, 
  description, 
  buttonText, 
  buttonAction,
  buttonLink,
  secondaryText,
  secondaryAction,
  secondaryLink
}) => {
  const navigate = useNavigate();
  
  const handlePrimaryClick = () => {
    if (buttonAction) {
      buttonAction();
    } else if (buttonLink) {
      navigate(createPageUrl(buttonLink));
    }
  };
  
  const handleSecondaryClick = () => {
    if (secondaryAction) {
      secondaryAction();
    } else if (secondaryLink) {
      navigate(createPageUrl(secondaryLink));
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-10 text-center">
      <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-6">
        {Icon && <Icon className="w-10 h-10 text-gray-400" />}
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-500 max-w-md mb-6">{description}</p>
      <div className="flex gap-3">
        {buttonText && (
          <Button 
            onClick={handlePrimaryClick}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {buttonText}
          </Button>
        )}
        {secondaryText && (
          <Button 
            variant="outline"
            onClick={handleSecondaryClick}
          >
            {secondaryText}
          </Button>
        )}
      </div>
    </div>
  );
};

export default EmptyState;