import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileText, Upload, Clock, CheckCircle, AlertTriangle, MoreHorizontal } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const statusConfig = {
  extraindo: {
    icon: FileText,
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    label: 'Extraindo Dados'
  },
  esperando_arquivos: {
    icon: Upload,
    color: 'bg-amber-100 text-amber-700 border-amber-200',
    label: 'Esperando Arquivos'
  },
  processando: {
    icon: Clock,
    color: 'bg-purple-100 text-purple-700 border-purple-200',
    label: 'Processando'
  },
  aguardando_aprovacao: {
    icon: Clock,
    color: 'bg-indigo-100 text-indigo-700 border-indigo-200',
    label: 'Aguardando Aprovação'
  },
  aprovado: {
    icon: CheckCircle,
    color: 'bg-green-100 text-green-700 border-green-200',
    label: 'Aprovado'
  },
  rejeitado: {
    icon: AlertTriangle,
    color: 'bg-red-100 text-red-700 border-red-200',
    label: 'Rejeitado'
  }
};

const OrdemProducaoItem = ({ op }) => {
  const navigate = useNavigate();
  const status = statusConfig[op.status] || statusConfig.extraindo;
  const StatusIcon = status.icon;

  const handleAction = () => {
    if (op.status === 'esperando_arquivos') {
      navigate(createPageUrl(`Arquivos?id=${op.id}`));
    } else if (op.status === 'aguardando_aprovacao') {
      navigate(createPageUrl(`Aprovacoes?id=${op.id}`));
    } else {
      navigate(createPageUrl(`Upload?id=${op.id}`));
    }
  };

  return (
    <div className="p-4 border rounded-lg bg-white hover:shadow-md transition-all">
      <div className="flex justify-between">
        <div>
          <h3 className="font-semibold text-gray-900 mb-1">{op.titulo || 'Sem título'}</h3>
          <div className="text-sm text-gray-500 mb-3">
            <span className="inline-flex items-center mr-3">
              <span className="font-medium mr-1">OP:</span> {op.numero_op || 'N/A'}
            </span>
            <span className="inline-flex items-center">
              <span className="font-medium mr-1">Cliente:</span> {op.cliente || 'N/A'}
            </span>
          </div>
        </div>
        <Badge className={`${status.color} border`}>
          <StatusIcon className="w-3.5 h-3.5 mr-1" />
          {status.label}
        </Badge>
      </div>

      <div className="flex flex-wrap gap-2 mb-4 mt-2">
        {op.prazo_entrega && (
          <div className="bg-gray-100 px-2 py-1 rounded-md text-xs flex items-center">
            <Clock className="w-3 h-3 mr-1 text-gray-500" />
            <span className="font-medium mr-1">Prazo:</span>
            {format(new Date(op.prazo_entrega), 'dd/MM/yyyy', { locale: ptBR })}
          </div>
        )}
        {op.quantidade && (
          <div className="bg-gray-100 px-2 py-1 rounded-md text-xs">
            <span className="font-medium mr-1">Quantidade:</span>
            {op.quantidade}
          </div>
        )}
        {op.vendedor && (
          <div className="bg-gray-100 px-2 py-1 rounded-md text-xs">
            <span className="font-medium mr-1">Vendedor:</span>
            {op.vendedor}
          </div>
        )}
      </div>

      <div className="flex justify-end">
        <Button
          variant="outline"
          size="sm"
          className="text-blue-600 border-blue-200 hover:bg-blue-50"
          onClick={handleAction}
        >
          {op.status === 'esperando_arquivos' ? 'Enviar Arquivos' : 
           op.status === 'aguardando_aprovacao' ? 'Ver Aprovação' : 'Ver Detalhes'}
        </Button>
      </div>
    </div>
  );
};

export default OrdemProducaoItem;