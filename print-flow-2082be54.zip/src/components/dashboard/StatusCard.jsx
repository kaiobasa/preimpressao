import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils'; // Assuming cn is available for classname composition

// Helper function to get class names based on status
const getStatusStyles = (status) => {
  switch (status) {
    case 'extraindo':
      return "bg-blue-100 text-blue-600";
    case 'esperando_arquivos':
      return "bg-amber-100 text-amber-600";
    case 'processando':
      return "bg-purple-100 text-purple-600";
    case 'aguardando_aprovacao':
      return "bg-indigo-100 text-indigo-600";
    case 'aprovado':
      return "bg-green-100 text-green-600";
    case 'rejeitado':
      return "bg-red-100 text-red-600";
    default:
      return "bg-gray-100 text-gray-600";
  }
};

const StatusCard = ({ icon: Icon, title, count, status, onClick }) => {
  return (
    <Card 
      className="hover:shadow-md transition-all cursor-pointer" 
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className={cn(
            "flex items-center justify-center w-12 h-12 rounded-full",
            getStatusStyles(status)
          )}>
            {Icon && <Icon className="w-6 h-6" />}
          </div>
          <div>
            <h3 className="font-medium text-gray-700 mb-1">{title}</h3>
            <p className="text-2xl font-bold">{count}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StatusCard;