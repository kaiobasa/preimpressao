import React, { useState } from 'react';
import { CheckCircle, X, Send, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { SendEmail } from '@/api/integrations';
import { Aprovacao } from '@/api/entities';
import { OrdemProducao } from '@/api/entities';

const AprovacaoForm = ({ op, onEnviar }) => {
  const [email, setEmail] = useState(op?.contato || '');
  const [mensagem, setMensagem] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState(null);

  const gerarTokenAcesso = () => {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
  };

  const handleEnviar = async (e) => {
    e.preventDefault();
    if (!email) {
      setErro('Por favor, informe um e-mail válido.');
      return;
    }

    setEnviando(true);
    setErro(null);

    try {
      // Gerar token de acesso
      const token = gerarTokenAcesso();
      
      // Criar registro de aprovação
      await Aprovacao.create({
        ordem_producao_id: op.id,
        email_cliente: email,
        data_envio: new Date().toISOString(),
        token_acesso: token,
        status: 'enviado'
      });
      
      // Atualizar status da OP
      await OrdemProducao.update(op.id, {
        status: 'aguardando_aprovacao'
      });
      
      // Enviar e-mail
      const urlAprovacao = `${window.location.origin}/aprovar/${token}`;
      
      await SendEmail({
        to: email,
        subject: `Aprovação de Arquivo - ${op.titulo || 'Ordem de Produção'}`,
        body: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #1a56db;">Aprovação de Arquivo</h2>
            <p>Prezado(a) cliente,</p>
            <p>Os arquivos da sua publicação "${op.titulo || 'Sem título'}" estão prontos para aprovação.</p>
            <p>${mensagem}</p>
            <p>Por favor, acesse o link abaixo para visualizar e aprovar os arquivos:</p>
            <p style="text-align: center; margin: 25px 0;">
              <a href="${urlAprovacao}" style="background-color: #1a56db; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">
                Visualizar e Aprovar
              </a>
            </p>
            <p>Se você tiver alguma dúvida ou precisar de esclarecimentos, por favor, entre em contato conosco.</p>
            <p>Atenciosamente,<br>Equipe de Pré-Impressão</p>
          </div>
        `
      });
      
      if (onEnviar) {
        onEnviar();
      }
    } catch (error) {
      setErro('Ocorreu um erro ao enviar o e-mail. Por favor, tente novamente.');
      console.error('Erro ao enviar aprovação:', error);
    } finally {
      setEnviando(false);
    }
  };

  return (
    <Card>
      <form onSubmit={handleEnviar}>
        <CardHeader>
          <CardTitle>Enviar para Aprovação</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">E-mail do Cliente</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email@cliente.com"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="mensagem">Mensagem (opcional)</Label>
            <Textarea
              id="mensagem"
              value={mensagem}
              onChange={(e) => setMensagem(e.target.value)}
              placeholder="Adicione uma mensagem personalizada para o cliente..."
              rows={4}
            />
          </div>
          
          {erro && (
            <div className="bg-red-50 text-red-700 p-3 rounded-md text-sm">
              {erro}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={() => onEnviar && onEnviar(false)}
          >
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button
            type="submit"
            disabled={enviando}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {enviando ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Enviando...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Enviar Aprovação
              </>
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
};

export default AprovacaoForm;