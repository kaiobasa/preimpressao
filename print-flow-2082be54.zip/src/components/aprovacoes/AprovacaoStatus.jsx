import React from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Send, Eye, CheckCircle, XCircle, Clock } from 'lucide-react';

const statusConfig = {
  enviado: {
    icon: Send,
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    label: 'Enviado para Aprovação'
  },
  visualizado: {
    icon: Eye,
    color: 'bg-amber-100 text-amber-700 border-amber-200',
    label: 'Visualizado pelo Cliente'
  },
  aprovado: {
    icon: CheckCircle,
    color: 'bg-green-100 text-green-700 border-green-200',
    label: 'Aprovado pelo Cliente'
  },
  rejeitado: {
    icon: XCircle,
    color: 'bg-red-100 text-red-700 border-red-200',
    label: 'Rejeitado pelo Cliente'
  }
};

const AprovacaoStatus = ({ aprovacao, onReenviar }) => {
  if (!aprovacao) return null;
  
  const status = statusConfig[aprovacao.status] || statusConfig.enviado;
  const StatusIcon = status.icon;
  
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Status da Aprovação</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <Badge className={`${status.color} border`}>
              <StatusIcon className="w-3.5 h-3.5 mr-1.5" />
              {status.label}
            </Badge>
            
            {aprovacao.status === 'enviado' && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={onReenviar}
              >
                <Send className="w-3.5 h-3.5 mr-1.5" />
                Reenviar
              </Button>
            )}
          </div>
          
          <div className="grid grid-cols-1 gap-3 mt-4">
            <div>
              <p className="text-sm text-gray-500">E-mail do Cliente</p>
              <p className="font-medium">{aprovacao.email_cliente}</p>
            </div>
            
            <div>
              <p className="text-sm text-gray-500">Data de Envio</p>
              <p className="font-medium">
                {format(new Date(aprovacao.data_envio), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
              </p>
            </div>
            
            {aprovacao.data_resposta && (
              <div>
                <p className="text-sm text-gray-500">Data da Resposta</p>
                <p className="font-medium">
                  {format(new Date(aprovacao.data_resposta), 'dd/MM/yyyy HH:mm', { locale: ptBR })}
                </p>
              </div>
            )}
            
            {aprovacao.comentarios && (
              <div>
                <p className="text-sm text-gray-500">Comentários do Cliente</p>
                <div className="bg-gray-50 p-3 rounded-md mt-1">
                  <p className="text-gray-800 whitespace-pre-line">{aprovacao.comentarios}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AprovacaoStatus;