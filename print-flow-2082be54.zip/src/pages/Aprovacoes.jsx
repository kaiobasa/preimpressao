import React, { useState, useEffect } from 'react';
import { OrdemProducao } from '@/api/entities';
import { ArquivoProducao } from '@/api/entities';
import { Aprovacao } from '@/api/entities';
import { ArrowLeft, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import AprovacaoForm from '../components/aprovacoes/AprovacaoForm';
import AprovacaoStatus from '../components/aprovacoes/AprovacaoStatus';
import FileList from '../components/arquivos/FileList';
import ExtractedDataViewer from '../components/upload/ExtractedDataViewer';
import EmptyState from '../components/comum/EmptyState';

export default function Aprovacoes() {
  const [op, setOp] = useState(null);
  const [arquivos, setArquivos] = useState([]);
  const [aprovacao, setAprovacao] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [erro, setErro] = useState(null);
  const [activeTab, setActiveTab] = useState('arquivos');
  const navigate = useNavigate();
  
  useEffect(() => {
    carregarDados();
  }, []);
  
  const carregarDados = async () => {
    try {
      setCarregando(true);
      const urlParams = new URLSearchParams(window.location.search);
      const opId = urlParams.get('id');
      
      if (!opId) {
        navigate(createPageUrl('Dashboard'));
        return;
      }
      
      // Carregar OP
      const ops = await OrdemProducao.list();
      const opEncontrada = ops.find(o => o.id === opId);
      
      if (!opEncontrada) {
        navigate(createPageUrl('Dashboard'));
        return;
      }
      
      setOp(opEncontrada);
      
      // Carregar arquivos relacionados
      const todosArquivos = await ArquivoProducao.list();
      const arquivosDaOP = todosArquivos.filter(a => a.ordem_producao_id === opId);
      setArquivos(arquivosDaOP);
      
      // Carregar aprovação relacionada
      const todasAprovacoes = await Aprovacao.list();
      const aprovacoesOP = todasAprovacoes.filter(a => a.ordem_producao_id === opId);
      
      if (aprovacoesOP.length > 0) {
        // Ordenar por data de envio (mais recente)
        aprovacoesOP.sort((a, b) => new Date(b.data_envio) - new Date(a.data_envio));
        setAprovacao(aprovacoesOP[0]);
      } else {
        setMostrarFormulario(true);
      }
      
    } catch (error) {
      console.error('Erro ao carregar dados:',  error);
      setErro('Erro ao carregar dados. Por favor, tente novamente.');
    } finally {
      setCarregando(false);
    }
  };
  
  const handleEnviarAprovacao = () => {
    carregarDados();
    setMostrarFormulario(false);
  };
  
  const temArquivosProcessados = arquivos.some(a => a.status_processamento === 'concluido');

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("Dashboard"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Aprovação
          </h1>
          <p className="text-gray-500">
            {op?.titulo || 'Carregando...'}
          </p>
        </div>
      </div>

      {erro && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{erro}</AlertDescription>
        </Alert>
      )}

      {carregando ? (
        <div className="animate-pulse space-y-6">
          <div className="bg-white rounded-lg h-64"></div>
          <div className="bg-white rounded-lg h-96"></div>
        </div>
      ) : op ? (
        <>
          {!temArquivosProcessados && !aprovacao ? (
            <EmptyState
              icon={CheckCircle}
              title="Nenhum arquivo processado"
              description="É necessário ter arquivos processados antes de enviar para aprovação."
              buttonText="Processar Arquivos"
              buttonLink={`Arquivos?id=${op.id}`}
            />
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                {mostrarFormulario ? (
                  <AprovacaoForm op={op} onEnviar={handleEnviarAprovacao} />
                ) : (
                  <AprovacaoStatus 
                    aprovacao={aprovacao} 
                    onReenviar={() => setMostrarFormulario(true)} 
                  />
                )}
                
                <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="mb-4">
                    <TabsTrigger value="arquivos">Arquivos Processados</TabsTrigger>
                    <TabsTrigger value="detalhes">Detalhes da OP</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="arquivos">
                    <FileList files={arquivos.filter(a => a.status_processamento === 'concluido')} />
                  </TabsContent>
                  
                  <TabsContent value="detalhes">
                    <ExtractedDataViewer op={op} />
                  </TabsContent>
                </Tabs>
              </div>
              
              <div>
                {/* Visualização de Flipbook seria implementada aqui */}
                <div className="bg-gray-100 border border-gray-200 p-4 rounded-lg text-center h-full flex flex-col justify-center items-center">
                  <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mb-4">
                    <CheckCircle className="w-12 h-12 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-700 mb-2">Visualização do Flipbook</h3>
                  <p className="text-gray-500 mb-4">
                    Aqui seria implementada uma visualização interativa do livro em formato flipbook para o cliente aprovar.
                  </p>
                  <p className="text-sm text-gray-400">
                    Esta é uma representação de interface do que seria a visualização final do produto.
                  </p>
                </div>
              </div>
            </div>
          )}
        </>
      ) : (
        <EmptyState
          icon={CheckCircle}
          title="Ordem de Produção não encontrada"
          description="A ordem de produção que você está procurando não foi encontrada."
          buttonText="Voltar ao Painel"
          buttonLink="Dashboard"
        />
      )}
    </div>
  );
}