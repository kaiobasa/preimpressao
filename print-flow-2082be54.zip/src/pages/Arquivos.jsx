import React, { useState, useEffect } from 'react';
import { OrdemProducao } from '@/api/entities';
import { ArquivoProducao } from '@/api/entities';
import { ArrowLeft, File, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { InvokeLLM } from '@/api/integrations';

import FileUploader from '../components/arquivos/FileUploader';
import FileList from '../components/arquivos/FileList';
import ExtractedDataViewer from '../components/upload/ExtractedDataViewer';
import EmptyState from '../components/comum/EmptyState';

export default function Arquivos() {
  const [op, setOp] = useState(null);
  const [arquivos, setArquivos] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [processando, setProcessando] = useState(false);
  const [erro, setErro] = useState(null);
  const navigate = useNavigate();
  
  useEffect(() => {
    carregarDados();
  }, []);
  
  const carregarDados = async () => {
    try {
      setCarregando(true);
      const urlParams = new URLSearchParams(window.location.search);
      const opId = urlParams.get('id');
      
      if (!opId) {
        navigate(createPageUrl('Dashboard'));
        return;
      }
      
      // Carregar OP
      const ops = await OrdemProducao.list();
      const opEncontrada = ops.find(o => o.id === opId);
      
      if (!opEncontrada) {
        navigate(createPageUrl('Dashboard'));
        return;
      }
      
      setOp(opEncontrada);
      
      // Carregar arquivos relacionados
      const todosArquivos = await ArquivoProducao.list();
      const arquivosDaOP = todosArquivos.filter(a => a.ordem_producao_id === opId);
      setArquivos(arquivosDaOP);
      
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      setErro('Erro ao carregar dados. Por favor, tente novamente.');
    } finally {
      setCarregando(false);
    }
  };
  
  const handleUploadComplete = () => {
    carregarDados();
  };
  
  const handleProcessarArquivos = async () => {
    try {
      setProcessando(true);
      setErro(null);
      
      // Filtrar arquivos aguardando processamento
      const arquivosPendentes = arquivos.filter(a => a.status_processamento === 'aguardando');
      
      if (arquivosPendentes.length === 0) {
        setErro('Não há arquivos aguardando processamento.');
        return;
      }
      
      // Atualizar status para "processando"
      for (const arquivo of arquivosPendentes) {
        await ArquivoProducao.update(arquivo.id, {
          status_processamento: 'processando'
        });
      }
      
      // Recarregar para mostrar status atualizado
      await carregarDados();
      
      // Simular processamento com LLM
      for (const arquivo of arquivosPendentes) {
        // Simulação do processamento com LLM
        const result = await InvokeLLM({
          prompt: `Simule o processamento de um arquivo ${arquivo.tipo_arquivo} para o padrão PDF/X-1A. 
                   O arquivo é "${arquivo.nome_arquivo}" para a ordem de produção "${op.titulo || 'Sem título'}".
                   Retorne um objeto JSON com 'status' (concluido ou erro), 'mensagem' (se houver erro) e 
                   'processos_realizados' (lista de processos realizados).`,
          response_json_schema: {
            type: "object",
            properties: {
              status: { type: "string", enum: ["concluido", "erro"] },
              mensagem: { type: "string" },
              processos_realizados: { type: "array", items: { type: "string" } }
            }
          }
        });
        
        if (result.status === "concluido") {
          // Atualizar arquivo para concluído
          await ArquivoProducao.update(arquivo.id, {
            status_processamento: 'concluido',
            // Em um caso real, aqui seria a URL do arquivo processado
            arquivo_processado_url: arquivo.arquivo_original_url,
            // Em um caso real, aqui seria a URL da imagem de preview
            preview_url: arquivo.arquivo_original_url
          });
        } else {
          // Atualizar arquivo com erro
          await ArquivoProducao.update(arquivo.id, {
            status_processamento: 'erro',
            mensagem_erro: result.mensagem || 'Erro no processamento do arquivo'
          });
        }
      }
      
      // Atualizar status da OP para "aguardando_aprovacao" se todos os arquivos foram processados
      const todosProcessados = true; // Em um caso real, verificaria se todos os arquivos necessários foram processados
      
      if (todosProcessados) {
        await OrdemProducao.update(op.id, {
          status: 'aguardando_aprovacao'
        });
        
        // Recarregar OP
        const ops = await OrdemProducao.list();
        const opAtualizada = ops.find(o => o.id === op.id);
        setOp(opAtualizada);
      }
      
      // Recarregar arquivos
      await carregarDados();
      
    } catch (error) {
      console.error('Erro ao processar arquivos:', error);
      setErro('Erro ao processar arquivos. Por favor, tente novamente.');
    } finally {
      setProcessando(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("Dashboard"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Arquivos da Ordem de Produção
          </h1>
          <p className="text-gray-500">
            {op?.titulo || 'Carregando...'}
          </p>
        </div>
      </div>

      {erro && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{erro}</AlertDescription>
        </Alert>
      )}

      {carregando ? (
        <div className="animate-pulse space-y-6">
          <div className="bg-white rounded-lg h-64"></div>
          <div className="bg-white rounded-lg h-96"></div>
        </div>
      ) : op ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <FileUploader 
              ordemProducaoId={op.id} 
              onUploadComplete={handleUploadComplete} 
            />
            
            <div className="space-y-6">
              {processando && (
                <div className="bg-blue-50 border border-blue-200 text-blue-700 p-4 rounded-lg flex items-center">
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Processando arquivos, isso pode levar alguns minutos...
                </div>
              )}
              
              <FileList 
                files={arquivos} 
                onProcessFiles={handleProcessarArquivos} 
              />
            </div>
          </div>
          
          <div>
            <ExtractedDataViewer op={op} />
          </div>
        </div>
      ) : (
        <EmptyState
          icon={File}
          title="Ordem de Produção não encontrada"
          description="A ordem de produção que você está procurando não foi encontrada."
          buttonText="Voltar ao Painel"
          buttonLink="Dashboard"
        />
      )}
    </div>
  );
}