import React, { useState } from 'react';
import { User } from '@/api/entities';
import { OrdemProducao } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Upload, ArrowLeft, Loader2, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function UploadComercial() {
  const [file, setFile] = useState(null);
  const [empresa, setEmpresa] = useState('infinitygrafica');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [userData, setUserData] = useState(null);
  const navigate = useNavigate();
  
  React.useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        setUserData(user);
      } catch (error) {
        console.error("Erro ao carregar dados do usuário");
        setError("Erro ao carregar dados do usuário. Por favor, recarregue a página.");
      }
    };
    
    fetchUser();
  }, []);

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      setError(null);
    } else {
      setFile(null);
      setError('Por favor, selecione um arquivo PDF válido.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      setError('Por favor, selecione um arquivo PDF.');
      return;
    }

    setUploading(true);
    setError(null);

    try {
      // Upload do arquivo
      const { file_url } = await UploadFile({ file });
      
      // Criar ordem de produção
      await OrdemProducao.create({
        op_pdf_url: file_url,
        status: 'extraindo',
        vendedor: userData?.full_name || 'Não especificado',
        empresa: empresa,
        data_upload: new Date().toISOString()
      });

      // Redirecionar para o dashboard
      navigate(createPageUrl('Dashboard'));
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
      setError('Erro ao fazer upload do arquivo. Por favor, tente novamente.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("Dashboard"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Upload Comercial</h1>
          <p className="text-gray-500">Faça upload de uma nova ordem de produção</p>
        </div>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Informações da Ordem</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label>Vendedor</Label>
              <Input
                value={userData?.full_name || ''}
                disabled
                className="bg-gray-50"
              />
            </div>

            <div className="space-y-2">
              <Label>Empresa</Label>
              <RadioGroup
                value={empresa}
                onValueChange={setEmpresa}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="infinitygrafica" id="infinitygrafica" />
                  <Label htmlFor="infinitygrafica">Infinity Gráfica</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="renovagraf" id="renovagraf" />
                  <Label htmlFor="renovagraf">Renovagraf</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label>Arquivo da Ordem de Produção (PDF)</Label>
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                <input
                  type="file"
                  accept="application/pdf"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                />
                {file ? (
                  <div className="space-y-2">
                    <p className="text-sm font-medium">{file.name}</p>
                    <p className="text-xs text-gray-500">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setFile(null)}
                    >
                      Remover arquivo
                    </Button>
                  </div>
                ) : (
                  <label
                    htmlFor="file-upload"
                    className="cursor-pointer inline-flex flex-col items-center"
                  >
                    <Upload className="h-8 w-8 text-gray-400 mb-2" />
                    <span className="text-sm font-medium text-gray-700">
                      Clique para selecionar um arquivo
                    </span>
                    <span className="text-xs text-gray-500 mt-1">
                      ou arraste e solte aqui
                    </span>
                  </label>
                )}
              </div>
            </div>

            <div className="flex justify-end">
              <Button
                type="submit"
                disabled={uploading || !file}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Enviar Ordem
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}