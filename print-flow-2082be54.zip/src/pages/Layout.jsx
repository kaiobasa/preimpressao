

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Menu, X, FileText, Upload, CheckCircle, Clock, Settings, LogOut } from 'lucide-react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export default function Layout({ children, currentPageName }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [userData, setUserData] = useState(null);
  
  React.useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        setUserData(user);
      } catch (error) {
        console.error("Erro ao carregar dados do usuário");
      }
    };
    
    fetchUser();
  }, []);

  const handleLogout = async () => {
    try {
      await User.logout();
      window.location.reload();
    } catch (error) {
      console.error("Erro ao fazer logout");
    }
  };
  
  if (currentPageName === 'PortalComercial') {
    return <>{children}</>;
  }

  const getPageTitle = () => {
    switch (currentPageName) {
      case 'Dashboard':
        return 'Painel de Controle';
      case 'Upload':
        return 'Upload de Ordem de Produção';
      case 'UploadComercial':
        return 'Upload Comercial (Interno)';
      case 'Arquivos':
        return 'Upload de Arquivos';
      case 'Aprovacoes':
        return 'Aprovações';
      case 'Configuracoes':
        return 'Configurações';
      default:
        return 'Agente de Pré-Impressão';
    }
  };

  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-50 to-gray-100 overflow-hidden">
      {/* Estilo global */}
      <style>
        {`
          :root {
            --primary: 215 100% 46%;
            --primary-foreground: 0 0% 100%;
            --background: 0 0% 100%;
            --foreground: 224 71% 4%;
            --muted: 220 14% 96%;
            --muted-foreground: 220 8% 46%;
            --accent: 220 14% 96%;
            --accent-foreground: 220 70% 10%;
            --destructive: 0 100% 50%;
            --destructive-foreground: 210 20% 98%;
            --border: 220 13% 91%;
            --input: 220 13% 91%;
            --ring: 224 71% 4%;
            --radius: 0.75rem;
          }
          
          body {
            font-family: 'Inter', sans-serif;
          }
          
          .animate-pulse {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
          }
          
          @keyframes pulse {
            0%, 100% {
              opacity: 1;
            }
            50% {
              opacity: .5;
            }
          }
        `}
      </style>

      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed top-0 left-0 z-50 h-full w-64 bg-white shadow-lg transform transition-transform duration-200 ease-in-out md:relative md:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex items-center justify-between h-16 px-4 border-b">
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-700 bg-clip-text text-transparent">
            Pré-Impressão
          </h1>
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="py-4">
          <div className="px-4 mb-6">
            <div className="flex items-center px-3 py-2 rounded-lg bg-gray-50">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 flex items-center justify-center text-white font-medium">
                {userData?.full_name ? userData.full_name.charAt(0).toUpperCase() : 'U'}
              </div>
              <div className="ml-3 overflow-hidden">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {userData?.full_name || 'Usuário'}
                </p>
                <p className="text-xs text-gray-500 truncate">
                  {userData?.email || 'carregando...'}
                </p>
              </div>
            </div>
          </div>

          <nav className="px-4 space-y-1">
            <Link
              to={createPageUrl("Dashboard")}
              className={cn(
                "flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors",
                currentPageName === "Dashboard" 
                  ? "bg-blue-50 text-blue-700 font-medium" 
                  : "text-gray-700 hover:bg-gray-100"
              )}
              onClick={() => setSidebarOpen(false)}
            >
              <FileText className="w-5 h-5" />
              Painel de Controle
            </Link>
            <Link
              to={createPageUrl("UploadComercial")}
              className={cn(
                "flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors",
                currentPageName === "UploadComercial" 
                  ? "bg-blue-50 text-blue-700 font-medium" 
                  : "text-gray-700 hover:bg-gray-100"
              )}
              onClick={() => setSidebarOpen(false)}
            >
              <Upload className="w-5 h-5" />
              Upload Comercial (Interno)
            </Link>
            <Link
              to={createPageUrl("Upload")}
              className={cn(
                "flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors",
                currentPageName === "Upload" 
                  ? "bg-blue-50 text-blue-700 font-medium" 
                  : "text-gray-700 hover:bg-gray-100"
              )}
              onClick={() => setSidebarOpen(false)}
            >
              <Upload className="w-5 h-5" />
              Upload de OP (Pré-Imp.)
            </Link>
            <Link
              to={createPageUrl("Arquivos")}
              className={cn(
                "flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors",
                currentPageName === "Arquivos" 
                  ? "bg-blue-50 text-blue-700 font-medium" 
                  : "text-gray-700 hover:bg-gray-100"
              )}
              onClick={() => setSidebarOpen(false)}
            >
              <CheckCircle className="w-5 h-5" />
              Arquivos
            </Link>
            <Link
              to={createPageUrl("Aprovacoes")}
              className={cn(
                "flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors",
                currentPageName === "Aprovacoes" 
                  ? "bg-blue-50 text-blue-700 font-medium" 
                  : "text-gray-700 hover:bg-gray-100"
              )}
              onClick={() => setSidebarOpen(false)}
            >
              <Clock className="w-5 h-5" />
              Aprovações
            </Link>
            <Link
              to={createPageUrl("Configuracoes")}
              className={cn(
                "flex items-center gap-3 px-3 py-2 text-sm rounded-lg transition-colors",
                currentPageName === "Configuracoes" 
                  ? "bg-blue-50 text-blue-700 font-medium" 
                  : "text-gray-700 hover:bg-gray-100"
              )}
              onClick={() => setSidebarOpen(false)}
            >
              <Settings className="w-5 h-5" />
              Configurações
            </Link>
          </nav>

          <div className="absolute bottom-4 left-0 right-0 px-4">
            <Button
              variant="ghost"
              className="w-full justify-start text-gray-700 hover:bg-gray-100"
              onClick={handleLogout}
            >
              <LogOut className="w-5 h-5 mr-3" />
              Sair
            </Button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm h-16 flex items-center px-4 z-10">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden mr-2"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold text-gray-800">
            {getPageTitle()}
          </h1>
        </header>

        {/* Main content area */}
        <main className="flex-1 overflow-auto p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

