import React, { useState, useEffect } from 'react';
import { OrdemProducao } from '@/api/entities';
import { ArquivoProducao } from '@/api/entities';
import { Aprovacao } from '@/api/entities';
import { FileText, Upload, Clock, CheckCircle, AlertTriangle, Filter, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import StatusCard from '../components/dashboard/StatusCard';
import OrdemProducaoItem from '../components/dashboard/OrdemProducaoItem';
import EmptyState from '../components/comum/EmptyState';

export default function Dashboard() {
  const [ordensProducao, setOrdensProducao] = useState([]);
  const [filteredOPs, setFilteredOPs] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  // Estatísticas
  const [estatisticas, setEstatisticas] = useState({
    esperando_arquivos: 0,
    processando: 0,
    aguardando_aprovacao: 0,
    aprovado: 0,
    rejeitado: 0
  });

  useEffect(() => {
    carregarDados();
  }, []);

  useEffect(() => {
    aplicarFiltros();
  }, [ordensProducao, filterStatus, searchQuery]);

  const carregarDados = async () => {
    setCarregando(true);
    try {
      const ops = await OrdemProducao.list('-created_date');
      setOrdensProducao(ops);

      // Calcular estatísticas
      const stats = {
        esperando_arquivos: 0,
        processando: 0,
        aguardando_aprovacao: 0,
        aprovado: 0,
        rejeitado: 0
      };

      ops.forEach(op => {
        if (stats[op.status] !== undefined) {
          stats[op.status]++;
        }
      });

      setEstatisticas(stats);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setCarregando(false);
    }
  };

  const aplicarFiltros = () => {
    let filtered = [...ordensProducao];
    
    // Filtrar por status
    if (filterStatus !== 'all') {
      filtered = filtered.filter(op => op.status === filterStatus);
    }
    
    // Filtrar por busca
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(op => 
        (op.titulo && op.titulo.toLowerCase().includes(query)) ||
        (op.cliente && op.cliente.toLowerCase().includes(query)) ||
        (op.numero_op && op.numero_op.toLowerCase().includes(query))
      );
    }
    
    setFilteredOPs(filtered);
  };

  const handleCreateOP = () => {
    navigate(createPageUrl('Upload'));
  };

  const handleStatusFilter = (status) => {
    setFilterStatus(status);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho com botão de criar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Painel de Controle</h1>
          <p className="text-gray-500">Gerencie suas ordens de produção</p>
        </div>
        <Button 
          onClick={handleCreateOP}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Upload className="w-4 h-4 mr-2" />
          Nova Ordem de Produção
        </Button>
      </div>

      {/* Cards de status */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        <StatusCard 
          icon={Upload} 
          title="Esperando Arquivos" 
          count={estatisticas.esperando_arquivos}
          status="esperando_arquivos"
          onClick={() => handleStatusFilter('esperando_arquivos')}
        />
        <StatusCard 
          icon={Clock} 
          title="Em Processamento" 
          count={estatisticas.processando}
          status="processando"
          onClick={() => handleStatusFilter('processando')}
        />
        <StatusCard 
          icon={Clock} 
          title="Aguardando Aprovação" 
          count={estatisticas.aguardando_aprovacao}
          status="aguardando_aprovacao"
          onClick={() => handleStatusFilter('aguardando_aprovacao')}
        />
        <StatusCard 
          icon={CheckCircle} 
          title="Aprovados" 
          count={estatisticas.aprovado}
          status="aprovado"
          onClick={() => handleStatusFilter('aprovado')}
        />
        <StatusCard 
          icon={AlertTriangle} 
          title="Rejeitados" 
          count={estatisticas.rejeitado}
          status="rejeitado"
          onClick={() => handleStatusFilter('rejeitado')}
        />
      </div>

      {/* Filtros e busca */}
      <div className="bg-white p-4 rounded-lg border shadow-sm">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar por título, cliente ou número OP..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="w-full md:w-48">
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger>
                <div className="flex items-center">
                  <Filter className="mr-2 h-4 w-4 text-gray-400" />
                  <SelectValue placeholder="Filtrar por status" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os status</SelectItem>
                <SelectItem value="esperando_arquivos">Esperando Arquivos</SelectItem>
                <SelectItem value="processando">Em Processamento</SelectItem>
                <SelectItem value="aguardando_aprovacao">Aguardando Aprovação</SelectItem>
                <SelectItem value="aprovado">Aprovados</SelectItem>
                <SelectItem value="rejeitado">Rejeitados</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Lista de OPs */}
      <div>
        {carregando ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="bg-white rounded-lg border p-4 animate-pulse">
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="flex gap-2 mb-4">
                  <div className="h-6 bg-gray-200 rounded w-24"></div>
                  <div className="h-6 bg-gray-200 rounded w-24"></div>
                </div>
                <div className="flex justify-end">
                  <div className="h-8 bg-gray-200 rounded w-32"></div>
                </div>
              </div>
            ))}
          </div>
        ) : filteredOPs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredOPs.map(op => (
              <OrdemProducaoItem key={op.id} op={op} />
            ))}
          </div>
        ) : (
          <EmptyState
            icon={FileText}
            title="Nenhuma ordem de produção encontrada"
            description={searchQuery || filterStatus !== 'all' ? 
              "Tente ajustar seus filtros de busca para encontrar o que procura." : 
              "Você ainda não tem nenhuma ordem de produção cadastrada."}
            buttonText={searchQuery || filterStatus !== 'all' ? "Limpar filtros" : "Criar Ordem de Produção"}
            buttonAction={searchQuery || filterStatus !== 'all' ? 
              () => {
                setSearchQuery('');
                setFilterStatus('all');
              } : 
              handleCreateOP}
          />
        )}
      </div>
    </div>
  );
}