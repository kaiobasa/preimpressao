import React, { useState } from 'react';
import { Save, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Switch } from '@/components/ui/switch';
import { User } from '@/api/entities';

export default function Configuracoes() {
  const [configuracoes, setConfiguracoes] = useState({
    email_padrao: '',
    mensagem_padrao: 'Olá,\n\nSegue para aprovação os arquivos do seu livro. Por favor, verifique e confirme se está tudo correto.\n\nAtenciosamente,\nEquipe de Pré-Impressão',
    notificacoes_email: true,
    notificacoes_sistema: true
  });
  
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState(null);
  const [sucesso, setSucesso] = useState(false);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setConfiguracoes(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSwitchChange = (name, checked) => {
    setConfiguracoes(prev => ({
      ...prev,
      [name]: checked
    }));
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setSalvando(true);
    setErro(null);
    setSucesso(false);
    
    try {
      // Salvar configurações no perfil do usuário
      await User.updateMyUserData({
        configuracoes_preimpressao: configuracoes
      });
      
      setSucesso(true);
      
      // Resetar status após 3 segundos
      setTimeout(() => {
        setSucesso(false);
      }, 3000);
    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
      setErro('Erro ao salvar configurações. Por favor, tente novamente.');
    } finally {
      setSalvando(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Configurações</h1>
      
      {erro && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{erro}</AlertDescription>
        </Alert>
      )}
      
      {sucesso && (
        <Alert className="mb-6 bg-green-50 border-green-200 text-green-800">
          <AlertDescription>Configurações salvas com sucesso!</AlertDescription>
        </Alert>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Aprovação</CardTitle>
              <CardDescription>
                Defina as configurações padrão para o envio de aprovações
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email_padrao">Email Padrão para Respostas</Label>
                <Input
                  id="email_padrao"
                  name="email_padrao"
                  type="email"
                  placeholder="seu@email.com"
                  value={configuracoes.email_padrao}
                  onChange={handleChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="mensagem_padrao">Mensagem Padrão de Aprovação</Label>
                <Textarea
                  id="mensagem_padrao"
                  name="mensagem_padrao"
                  rows={6}
                  value={configuracoes.mensagem_padrao}
                  onChange={handleChange}
                />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Notificações</CardTitle>
              <CardDescription>
                Configure como você deseja ser notificado sobre as atividades
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notificacoes_email" className="block">Notificações por Email</Label>
                  <p className="text-sm text-gray-500">Receba um email quando um cliente aprovar ou rejeitar um arquivo</p>
                </div>
                <Switch
                  id="notificacoes_email"
                  checked={configuracoes.notificacoes_email}
                  onCheckedChange={(checked) => handleSwitchChange('notificacoes_email', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notificacoes_sistema" className="block">Notificações no Sistema</Label>
                  <p className="text-sm text-gray-500">Receba notificações no sistema sobre o status das ordens de produção</p>
                </div>
                <Switch
                  id="notificacoes_sistema"
                  checked={configuracoes.notificacoes_sistema}
                  onCheckedChange={(checked) => handleSwitchChange('notificacoes_sistema', checked)}
                />
              </div>
            </CardContent>
          </Card>
          
          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={salvando}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {salvando ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Configurações
                </>
              )}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}