
import React, { useState, useEffect } from 'react';
import { OrdemProducao } from '@/api/entities';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import UploadForm from '../components/upload/UploadForm';
import ExtractedDataViewer from '../components/upload/ExtractedDataViewer';

export default function Upload() {
  const [op, setOp] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [activeTab, setActiveTab] = useState('upload');
  const navigate = useNavigate();
  const [opIdFromUrl, setOpIdFromUrl] = useState(null);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const opId = urlParams.get('id');
    if (opId) {
      setOpIdFromUrl(opId);
      carregarOP(opId);
    }
  }, []);

  const carregarOP = async (id) => {
    setCarregando(true);
    try {
      const todasOps = await OrdemProducao.list();
      const encontrada = todasOps.find(o => o.id === id);
      
      if (encontrada) {
        setOp(encontrada);
        setActiveTab('detalhes');
      } else {
        console.warn(`OP com ID ${id} não encontrada.`);
        setOp(null);
        setActiveTab('upload');
      }
    } catch (error) {
      console.error('Erro ao carregar OP:', error);
    } finally {
      setCarregando(false);
    }
  };
  
  const handleUploadComplete = async () => {
    if (opIdFromUrl) {
        await carregarOP(opIdFromUrl);
    } else {
        const opsRecentes = await OrdemProducao.list('-created_date', 1);
        if (opsRecentes.length > 0) {
            setOp(opsRecentes[0]);
            setOpIdFromUrl(opsRecentes[0].id)
            setActiveTab('detalhes');
        } else {
            setActiveTab('upload');
        }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          size="icon"
          onClick={() => navigate(createPageUrl("Dashboard"))}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            {op ? 'Detalhes da Ordem de Produção' : 'Upload e Extração de OP'}
          </h1>
          <p className="text-gray-500">
            {op ? 'Visualize os dados extraídos ou faça um novo upload para atualizar.' : 'Faça upload do PDF da ordem de produção para extrair os dados.'}
          </p>
        </div>
      </div>

      {carregando ? (
        <div className="animate-pulse">
          <div className="bg-white rounded-lg h-96 flex items-center justify-center">
            <Loader2 className="w-12 h-12 text-gray-300 animate-spin" />
          </div>
        </div>
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="mb-6 grid w-full grid-cols-2 md:max-w-md">
            <TabsTrigger value="upload">Upload / Editar PDF</TabsTrigger>
            <TabsTrigger value="detalhes" disabled={!op}>Dados Extraídos</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upload">
            <UploadForm existingOP={op} onComplete={handleUploadComplete} />
          </TabsContent>
          
          <TabsContent value="detalhes">
            {op ? (
              <ExtractedDataViewer op={op} />
            ) : (
              <div className="text-center py-8 text-gray-500">
                Nenhuma OP selecionada ou dados para exibir. Faça upload na aba anterior.
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
