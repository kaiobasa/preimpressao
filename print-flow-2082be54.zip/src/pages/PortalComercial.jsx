
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { OrdemProducao } from '@/api/entities';
import { ArquivoProducao } from '@/api/entities';
import { Aprovacao } from '@/api/entities';
import { UploadFile, ExtractDataFromUploadedFile } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Upload, Search, Loader2, AlertCircle, CheckCircle, Clock, Eye, LogOut, FileText, Image as ImageIcon } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';
import { cn } from "@/lib/utils";

const statusLabels = {
  extraindo: "Extraindo Dados",
  esperando_arquivos: "Aguardando Arquivos Internos",
  processando: "Processando Arquivos",
  aguardando_aprovacao: "Aguardando Aprovação do Cliente",
  aprovado: "Aprovado pelo Cliente",
  rejeitado: "Rejeitado pelo Cliente"
};

const statusIcons = {
  extraindo: <Clock className="w-4 h-4" />,
  esperando_arquivos: <Clock className="w-4 h-4" />,
  processando: <Clock className="w-4 h-4" />,
  aguardando_aprovacao: <Eye className="w-4 h-4" />,
  aprovado: <CheckCircle className="w-4 h-4 text-green-600" />,
  rejeitado: <AlertCircle className="w-4 h-4 text-red-600" />
};

const statusColors = {
  extraindo: "bg-yellow-100 text-yellow-700",
  esperando_arquivos: "bg-amber-100 text-amber-700",
  processando: "bg-blue-100 text-blue-700",
  aguardando_aprovacao: "bg-indigo-100 text-indigo-700",
  aprovado: "bg-green-100 text-green-700",
  rejeitado: "bg-red-100 text-red-700"
};


const simplifiedExtractionSchema = {
    type: "object",
    properties: {
        numero_op: { type: "string", description: "Número da OP" },
        orcamento: { type: "string", description: "Número do Orçamento" },
        emissao: { type: "string", format: "date", description: "Data de Emissão (AAAA-MM-DD)" },
        data_prova: { type: "string", format: "date", description: "Data da Prova (AAAA-MM-DD)" },
        prazo_entrega: { type: "string", format: "date", description: "Prazo de Entrega (AAAA-MM-DD)" },
        quantidade: { type: "number", description: "Quantidade" },
        cliente: { type: "string", description: "Nome do Cliente" },
        contato: { type: "string", description: "Contato do Cliente" },
        endereco: { type: "string", description: "Endereço de Entrega" },
        titulo: { type: "string", description: "Título da Obra" },
        isbn: { type: "string", description: "ISBN" },
        formato: { type: "string", description: "Formato do Material (ex: 21x28 cm)" },
        capa_papel: { type: "string", description: "Papel da Capa" },
        capa_cores: { type: "string", description: "Cores da Capa (ex: 4x0)" },
        capa_laminacao: { type: "string", description: "Laminação da Capa" },
        miolo_paginas: { type: "number", description: "Número de Páginas do Miolo" },
        miolo_papel: { type: "string", description: "Papel do Miolo" },
        miolo_cores: { type: "string", description: "Cores do Miolo (ex: 1x1)" },
        acabamento: { type: "string", description: "Tipo de Acabamento" },
        shrink: { type: "boolean", description: "Aplicar Shrink (true/false)" },
        tipo_prova: { type: "string", description: "Tipo de Prova" },
        entrega: { type: "string", description: "Local/Observações de Entrega" },
    }
};


const ProducaoFileUpload = ({ loggedInCompany, op }) => {
  const [capaFile, setCapaFile] = useState(null);
  const [mioloFile, setMioloFile] = useState(null);
  const [uploadingCapa, setUploadingCapa] = useState(false);
  const [uploadingMiolo, setUploadingMiolo] = useState(false);
  const [fileError, setFileError] = useState(null);
  const [fileSuccess, setFileSuccess] = useState('');
  const [existingFiles, setExistingFiles] = useState({ capa: null, miolo: null });

  const fetchExistingFiles = useCallback(async () => {
    if (op?.id) {
      const arquivos = await ArquivoProducao.filter({ ordem_producao_id: op.id });
      const capa = arquivos.find(f => f.tipo_arquivo === 'capa');
      const miolo = arquivos.find(f => f.tipo_arquivo === 'miolo');
      setExistingFiles({ capa, miolo });
    }
  }, [op?.id]);

  useEffect(() => {
    fetchExistingFiles();
  }, [fetchExistingFiles]);


  const handleSingleFileUpload = async (file, tipoArquivo, setLoading) => {
    if (!file || !op?.id) {
      setFileError(`Selecione o arquivo de ${tipoArquivo} e certifique-se que uma OP está carregada.`);
      return;
    }
    setLoading(true);
    setFileError(null);
    setFileSuccess('');

    try {
      const { file_url } = await UploadFile({ file });
      await ArquivoProducao.create({
        ordem_producao_id: op.id,
        nome_arquivo: file.name,
        tipo_arquivo: tipoArquivo,
        arquivo_original_url: file_url,
        status_processamento: 'aguardando' // Processamento pela pré-impressão
      });
      setFileSuccess(`Arquivo de ${tipoArquivo} enviado com sucesso!`);
      if (tipoArquivo === 'capa') setCapaFile(null);
      if (tipoArquivo === 'miolo') setMioloFile(null);
      fetchExistingFiles(); // Re-fetch para atualizar
    } catch (err) {
      console.error(`Erro ao enviar ${tipoArquivo}:`, err);
      setFileError(`Erro ao enviar arquivo de ${tipoArquivo}. Tente novamente.`);
    } finally {
      setLoading(false);
    }
  };

  if (!op) return <p className="text-sm text-slate-500">Primeiro, envie e processe uma OP ou busque uma existente para anexar arquivos.</p>;
  if (op.status === 'extraindo' && !op.log_extracao?.includes("Falha na extração")) { 
    // Se está extraindo e não é uma falha manual, aguarde.
    return <p className="text-sm text-slate-500">Aguarde a extração dos dados da OP antes de enviar arquivos de produção.</p>;
  }
  if (op.status === 'extraindo' && op.log_extracao?.includes("Falha na extração")){
    // Se houve falha na extração, pode permitir o upload de arquivos
     // mas idealmente o usuário deveria corrigir a OP antes ou ter uma opção de upload manual de dados
  }


  return (
    <Card className="shadow-lg mt-8">
      <CardHeader>
        <CardTitle className="text-2xl text-sky-600">Arquivos de Produção para OP: {op.numero_op || op.titulo || 'N/A'}</CardTitle>
        <CardDescription>Envie os arquivos de capa e miolo para esta Ordem de Produção.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {fileError && <Alert variant="destructive"><AlertDescription>{fileError}</AlertDescription></Alert>}
        {fileSuccess && <Alert variant="success" className="bg-green-50 border-green-200 text-green-700"><AlertDescription>{fileSuccess}</AlertDescription></Alert>}

        {/* Upload Capa */}
        <div className="space-y-2">
          <Label htmlFor="capa-file-upload">Arquivo da Capa</Label>
          {existingFiles.capa ? (
            <div className="p-2 border rounded-md bg-slate-50 text-sm">
              <FileText className="w-4 h-4 inline mr-2 text-blue-500" />
              Capa já enviada: {existingFiles.capa.nome_arquivo} ({statusLabels[existingFiles.capa.status_processamento] || existingFiles.capa.status_processamento })
            </div>
          ) : (
            <>
              <Input id="capa-file-upload" type="file" onChange={(e) => setCapaFile(e.target.files[0])} disabled={uploadingCapa} />
              <Button onClick={() => handleSingleFileUpload(capaFile, 'capa', setUploadingCapa)} disabled={uploadingCapa || !capaFile} className="mt-2">
                {uploadingCapa ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />} Enviar Capa
              </Button>
            </>
          )}
        </div>

        {/* Upload Miolo */}
        <div className="space-y-2">
          <Label htmlFor="miolo-file-upload">Arquivo do Miolo</Label>
           {existingFiles.miolo ? (
            <div className="p-2 border rounded-md bg-slate-50 text-sm">
              <ImageIcon className="w-4 h-4 inline mr-2 text-purple-500" />
              Miolo já enviado: {existingFiles.miolo.nome_arquivo} ({statusLabels[existingFiles.miolo.status_processamento] || existingFiles.miolo.status_processamento})
            </div>
          ) : (
            <>
              <Input id="miolo-file-upload" type="file" onChange={(e) => setMioloFile(e.target.files[0])} disabled={uploadingMiolo} />
              <Button onClick={() => handleSingleFileUpload(mioloFile, 'miolo', setUploadingMiolo)} disabled={uploadingMiolo || !mioloFile} className="mt-2">
                {uploadingMiolo ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />} Enviar Miolo
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};


export default function PortalComercial() {
  const [loggedInCompany, setLoggedInCompany] = useState(null); // null, 'Infinity', 'Renova'
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // Estados para Upload de OP PDF
  const [opFile, setOpFile] = useState(null);
  const [atendenteNome, setAtendenteNome] = useState(''); 
  const [uploadingOP, setUploadingOP] = useState(false);
  const [opUploadProgressMessage, setOpUploadProgressMessage] = useState('');
  const [opUploadError, setOpUploadError] = useState(null);
  const [opUploadSuccess, setOpUploadSuccess] = useState(false);
  const [uploadedOrSearchedOp, setUploadedOrSearchedOp] = useState(null);

  // Estados para Consulta de Status
  const [searchQuery, setSearchQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState(null);
  
  const credentials = {
    Infinity: "Infinity@1019",
    Renova: "Renova@1019"
  };

  const handleSimulatedLogin = (e) => {
    e.preventDefault();
    setLoginError('');
    if (credentials[username] && credentials[username] === password) {
      setLoggedInCompany(username);
      setAtendenteNome(''); 
    } else {
      setLoginError("Usuário ou senha inválidos.");
    }
  };

  const handleSimulatedLogout = () => {
    setLoggedInCompany(null);
    setUsername('');
    setPassword('');
    setOpFile(null);
    setAtendenteNome('');
    setOpUploadError(null);
    setOpUploadSuccess(false);
    setSearchQuery('');
    setUploadedOrSearchedOp(null);
    setSearchError(null);
  };
  
  const handleOpFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setOpFile(selectedFile);
      setOpUploadError(null);
      setOpUploadSuccess(false);
    } else {
      setOpFile(null);
      setOpUploadError('Por favor, selecione um arquivo PDF válido para a OP.');
    }
  };

  const handleOpUploadSubmit = async (e) => {
    e.preventDefault();
    if (!opFile || !loggedInCompany || !atendenteNome.trim()) {
      setOpUploadError('Arquivo da OP, nome do atendente e informações da empresa são obrigatórios.');
      return;
    }

    setUploadingOP(true);
    setOpUploadError(null);
    setOpUploadSuccess(false);
    setUploadedOrSearchedOp(null);
    setOpUploadProgressMessage('Enviando arquivo da OP...');

    let empresaFinal = '';
    if (loggedInCompany === 'Infinity') {
        empresaFinal = 'infinitygrafica';
    } else if (loggedInCompany === 'Renova') {
        empresaFinal = 'renovagraf';
    }

    try {
      const { file_url } = await UploadFile({ file: opFile });
      setOpUploadProgressMessage('Extraindo dados da Ordem de Produção...');
      
      const extractionResult = await ExtractDataFromUploadedFile({
        file_url: file_url,
        json_schema: simplifiedExtractionSchema // Usar o schema simplificado
      });

      let newOp;
      const baseOpData = {
        op_pdf_url: file_url,
        vendedor: atendenteNome.trim(),
        empresa: empresaFinal,
        data_upload: new Date().toISOString(),
      };

      if (extractionResult.status === 'success' && extractionResult.output && Object.keys(extractionResult.output).length > 0) {
        const opData = {
          ...baseOpData,
          ...extractionResult.output, 
          status: 'esperando_arquivos', 
        };
        newOp = await OrdemProducao.create(opData);
        setOpUploadSuccess(true);
        setOpUploadError(null);
      } else {
        const opData = {
            ...baseOpData,
            status: 'extraindo', 
            log_extracao: `Falha na extração automática: ${extractionResult.details || 'Nenhum dado extraído ou erro desconhecido.'}`
        };
        newOp = await OrdemProducao.create(opData);
        setOpUploadError(`OP enviada, mas a extração automática de dados falhou. Verifique o PDF ou preencha manualmente na pré-impressão. Detalhes: ${extractionResult.details || 'Nenhum dado extraído.'}`);
        setOpUploadSuccess(false);
      }
      setUploadedOrSearchedOp(newOp); 
      setOpFile(null);
      // Não limpar atendenteNome aqui, pode ser útil para múltiplos uploads
      // setAtendenteNome(''); 

    } catch (error) {
      console.error('Erro no upload/extração da OP:', error);
      setOpUploadError(`Erro crítico durante o upload ou extração da OP. Tente novamente. Detalhe: ${error.message}`);
      setOpUploadSuccess(false);
    } finally {
      setUploadingOP(false);
      setOpUploadProgressMessage('');
    }
  };
  
  const handleSearchSubmit = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      setSearchError('Digite o número da OP para pesquisar.');
      return;
    }

    setSearching(true);
    setSearchError(null);
    setUploadedOrSearchedOp(null);
    
    let empresaBusca = '';
    if (loggedInCompany === 'Infinity') {
        empresaBusca = 'infinitygrafica';
    } else if (loggedInCompany === 'Renova') {
        empresaBusca = 'renovagraf';
    }

    try {
      const ops = await OrdemProducao.filter({ 
        numero_op: searchQuery.trim(),
        empresa: empresaBusca 
      });

      if (ops && ops.length > 0) {
        const op = ops[0];
        let aprovacaoInfo = null;
        if (['aguardando_aprovacao', 'aprovado', 'rejeitado'].includes(op.status)) {
          const aprovacoes = await Aprovacao.filter({ ordem_producao_id: op.id }, '-data_envio', 1);
          if (aprovacoes && aprovacoes.length > 0) {
            aprovacaoInfo = aprovacoes[0];
          }
        }
        setUploadedOrSearchedOp({ ...op, aprovacaoInfo });
        setSearchError(null); 
      } else {
        setSearchError(`Nenhuma OP encontrada com o número "${searchQuery.trim()}" para ${loggedInCompany}.`);
      }
    } catch (error) {
      console.error('Erro na busca:', error);
      setSearchError('Erro ao buscar a OP. Tente novamente.');
    } finally {
      setSearching(false);
    }
  };


  if (!loggedInCompany) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-sky-100 p-4">
        <style>{`body { background-color: transparent !important; }`}</style>
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-sky-700">Portal Comercial</CardTitle>
            <CardDescription>Acesso restrito à equipe de vendas.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSimulatedLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username">Usuário</Label>
                <Input id="username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Infinity ou Renova" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              {loginError && <Alert variant="destructive"><AlertDescription>{loginError}</AlertDescription></Alert>}
              <Button type="submit" className="w-full bg-sky-600 hover:bg-sky-700">Entrar</Button>
            </form>
          </CardContent>
        </Card>
         <footer className="text-center mt-8 text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} Gráficas Associadas. Todos os direitos reservados.</p>
        </footer>
      </div>
    );
  }

  // Conteúdo principal após login
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 to-sky-100 py-8 px-4">
      <style>{`body { background-color: transparent !important; }`}</style>
      <div className="max-w-5xl mx-auto">
        <header className="flex justify-between items-center mb-12">
          <div>
            <h1 className="text-4xl font-bold text-sky-700">Portal Comercial</h1>
            <p className="text-lg text-slate-600">Bem-vindo, {loggedInCompany}!</p>
          </div>
          <Button variant="outline" onClick={handleSimulatedLogout}>
            <LogOut className="w-4 h-4 mr-2" /> Sair
          </Button>
        </header>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Seção de Upload de OP */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-sky-600">Nova Ordem de Produção</CardTitle>
              <CardDescription>Faça o upload do arquivo PDF da OP. Os dados serão extraídos automaticamente.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleOpUploadSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="atendente-nome">Nome do Atendente</Label>
                  <Input 
                    id="atendente-nome" 
                    value={atendenteNome} 
                    onChange={(e) => setAtendenteNome(e.target.value)} 
                    placeholder="Digite o nome do atendente" 
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label>Empresa</Label>
                  <Input value={loggedInCompany} disabled className="bg-slate-50" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="op-file-upload">Arquivo PDF da OP</Label>
                  <div 
                    className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center cursor-pointer hover:border-sky-400 transition-colors"
                    onClick={() => document.getElementById('op-file-upload')?.click()}
                  >
                    <input type="file" accept="application/pdf" onChange={handleOpFileChange} className="hidden" id="op-file-upload" />
                    {opFile ? (
                      <div className="space-y-1">
                        <p className="text-sm font-medium text-slate-700">{opFile.name}</p>
                        <p className="text-xs text-slate-500">{(opFile.size / 1024 / 1024).toFixed(2)} MB</p>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center text-slate-500">
                        <Upload className="h-10 w-10 mb-2" />
                        <span className="text-sm font-medium">Clique ou arraste para enviar OP</span>
                      </div>
                    )}
                  </div>
                  {uploadingOP && <p className="text-sm text-sky-600 mt-2 animate-pulse">{opUploadProgressMessage}</p>}
                  {opUploadError && <Alert variant="destructive" className="mt-2"><AlertDescription>{opUploadError}</AlertDescription></Alert>}
                  {opUploadSuccess && <Alert variant="success" className="mt-2 bg-green-50 border-green-200 text-green-700"><AlertDescription>OP enviada e dados extraídos com sucesso! Verifique os detalhes abaixo ou na busca. Agora você pode enviar os arquivos de produção.</AlertDescription></Alert>}
                </div>
                <Button type="submit" disabled={uploadingOP || !opFile || !atendenteNome.trim()} className="w-full bg-sky-600 hover:bg-sky-700">
                  {uploadingOP ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                  {uploadingOP ? opUploadProgressMessage.startsWith('Extraindo') ? 'Processando OP...' : 'Enviando OP...' : 'Enviar e Processar OP'}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Seção de Consulta de Status */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-sky-600">Consultar Status da OP</CardTitle>
              <CardDescription>Verifique o andamento de uma Ordem de Produção.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSearchSubmit} className="space-y-4 mb-6">
                <div className="space-y-2">
                  <Label htmlFor="search-op-portal">Número da OP</Label>
                  <div className="flex gap-2">
                    <Input id="search-op-portal" placeholder="Ex: OP-12345" value={searchQuery} onChange={(e) => { setSearchQuery(e.target.value); setSearchError(null); if (!uploadingOP) setUploadedOrSearchedOp(null);}} />
                    <Button type="submit" disabled={searching} className="bg-sky-600 hover:bg-sky-700">
                      {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                    </Button>
                  </div>
                  {searchError && <Alert variant="destructive" className="mt-2"><AlertDescription>{searchError}</AlertDescription></Alert>}
                </div>
              </form>
              {uploadedOrSearchedOp && !searching && ( 
                <div className="border border-slate-200 rounded-lg p-4 space-y-3 bg-slate-50">
                  <h3 className="text-lg font-semibold text-slate-800">Detalhes da OP: {uploadedOrSearchedOp.numero_op || 'N/A'}</h3>
                  <div className="flex items-center gap-2">
                    <Badge className={cn("px-2 py-1 text-xs font-medium", statusColors[uploadedOrSearchedOp.status] || 'bg-slate-200 text-slate-700')}>
                      {React.cloneElement(statusIcons[uploadedOrSearchedOp.status] || <Clock className="w-4 h-4" />, { className: cn("w-4 h-4", statusIcons[uploadedOrSearchedOp.status]?.props.className) })}
                      <span className="ml-1.5">{statusLabels[uploadedOrSearchedOp.status] || uploadedOrSearchedOp.status}</span>
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600"><strong>Título:</strong> {uploadedOrSearchedOp.titulo || 'Não informado'}</p>
                  <p className="text-sm text-slate-600"><strong>Cliente:</strong> {uploadedOrSearchedOp.cliente || 'Não informado'}</p>
                   <p className="text-sm text-slate-600"><strong>Atendente:</strong> {uploadedOrSearchedOp.vendedor || 'Não informado'}</p>
                  <p className="text-sm text-slate-600"><strong>Data do Upload OP:</strong> {uploadedOrSearchedOp.data_upload ? format(new Date(uploadedOrSearchedOp.data_upload), 'dd/MM/yyyy HH:mm', { locale: ptBR }) : 'Não informado'}</p>
                  {uploadedOrSearchedOp.log_extracao && <p className="text-xs text-orange-600"><strong>Log Extração:</strong> {uploadedOrSearchedOp.log_extracao}</p>}
                  {uploadedOrSearchedOp.aprovacaoInfo && (
                    <>
                      <Separator className="my-2" />
                      <p className="text-sm font-medium text-slate-700">Informações da Aprovação:</p>
                      <p className="text-sm text-slate-600"><strong>Status:</strong> {statusLabels[uploadedOrSearchedOp.aprovacaoInfo.status] || uploadedOrSearchedOp.aprovacaoInfo.status}</p>
                      <p className="text-sm text-slate-600"><strong>Enviado em:</strong> {format(new Date(uploadedOrSearchedOp.aprovacaoInfo.data_envio), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</p>
                      {uploadedOrSearchedOp.aprovacaoInfo.data_resposta && <p className="text-sm text-slate-600"><strong>Respondido em:</strong> {format(new Date(uploadedOrSearchedOp.aprovacaoInfo.data_resposta), 'dd/MM/yyyy HH:mm', { locale: ptBR })}</p>}
                      {uploadedOrSearchedOp.aprovacaoInfo.comentarios && <p className="text-sm text-slate-600"><strong>Comentários:</strong> {uploadedOrSearchedOp.aprovacaoInfo.comentarios}</p>}
                    </>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {uploadedOrSearchedOp && (
           <ProducaoFileUpload loggedInCompany={loggedInCompany} op={uploadedOrSearchedOp} />
        )}


        <footer className="text-center mt-12 text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} Gráficas Associadas. Todos os direitos reservados.</p>
        </footer>
      </div>
    </div>
  );
}
